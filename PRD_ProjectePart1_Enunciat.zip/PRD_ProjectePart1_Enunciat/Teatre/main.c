/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "tests.h"


int main(int argc, char** argv)
{
    t_teatre teatre;
    
    carregar_clients_test(&teatre);
    carregar_espectacles_test(&teatre);
    
    printf("***********************************************\n");
    printf("*             LA SALA DE TEATRE               *\n");
    printf("*   Programacio i Estructures de Dades (PRD)  *\n");
    printf("*       ETSETB-GREELEC: Curs 2022/2023        *\n");
    printf("***********************************************\n\n");
    
    mostrar_ajuda();
    
    
    /* Falta completar el codi de la funció... */
    
    
    printf ("\nFinalitzant l'aplicacio...\n");
    return (EXIT_SUCCESS);
}

void mostrar_ajuda()
{
    printf("Opcions disponibles:\n");
    printf("\t[R]egistrar nou client\n");
    printf("\t[I]ntroduir nou espectacle\n");
    printf("\t[M]ostrar espectacles oferts\n");
    printf("\t[V]eure estat butaques\n");
    printf("\t[C]omprar entrada\n");
    printf("\t[D]ades client\n");
    printf("\t[A]juda\n");
    printf("\t[F]inalitzar\n");
}

void carregar_clients_test(t_teatre *t)
{
    t_client c1 = {{11111111,'A'},"Sonia Perez Vila", 60, 0,{}};
    t_client c2 = {{22222222,'B'},"Joan Serra Pou", 25, 0,{}};
    t_client c3 = {{33333333,'C'},"Marta Garcia Duran", 90, 0,{}};
    
    t->ncli = 3;
    t->clients[0] = c1;
    t->clients[1] = c2;
    t->clients[2] = c3;
}

void carregar_espectacles_test(t_teatre *t)
{
    t->nesp = 3;
    
    strcpy(t->espectacles[0].titol, "El metode Gronholm");
    t->espectacles[0].durada = 90;
    t->espectacles[0].nsessions = 1;
    t->espectacles[0].sessions[0].data = 20230325;
    t->espectacles[0].sessions[0].hora_ini = 1800;
    t->espectacles[0].sessions[0].preu = 20;
    
    strcpy(t->espectacles[1].titol, "Mar i Cel");
    t->espectacles[1].durada = 150;
    t->espectacles[1].nsessions = 2;
    t->espectacles[1].sessions[0].data = 20230422;
    t->espectacles[1].sessions[0].hora_ini = 1700;
    t->espectacles[1].sessions[0].preu = 25;
    t->espectacles[1].sessions[1].data = 20230423;
    t->espectacles[1].sessions[1].hora_ini = 1700;
    t->espectacles[1].sessions[1].preu = 30;

    strcpy(t->espectacles[2].titol, "West Side Story");
    t->espectacles[2].durada = 120;
    t->espectacles[2].nsessions = 1;
    t->espectacles[2].sessions[0].data = 20230513;
    t->espectacles[2].sessions[0].hora_ini = 1730;
    t->espectacles[2].sessions[0].preu = 20;
    
    /* Cal descomentar el codi següent un cop implementada la funció 
       preparar_butaques() al fitxer de codi font espectacle.c */
    
    /* preparar_butaques(&t->espectacles[0].sessions[0]);
    preparar_butaques(&t->espectacles[1].sessions[0]);
    preparar_butaques(&t->espectacles[1].sessions[1]);
    preparar_butaques(&t->espectacles[2].sessions[0]); */
}