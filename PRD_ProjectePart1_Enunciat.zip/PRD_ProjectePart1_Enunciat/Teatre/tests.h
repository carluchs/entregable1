/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#ifndef TESTS_H
#define TESTS_H

void test_espectacle1();
void test_espectacle2();
void test_client1();
void test_client2();

#endif /* TESTS_H */

