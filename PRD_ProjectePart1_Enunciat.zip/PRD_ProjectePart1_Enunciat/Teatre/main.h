/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#ifndef MAIN_H
#define MAIN_H

#include "teatre.h"

void mostrar_ajuda();
void carregar_clients_test(t_teatre *t);
void carregar_espectacles_test(t_teatre *t);
int main(int argc, char** argv);

#endif /* MAIN_H */

