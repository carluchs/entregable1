/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#ifndef TEATRE_H
#define TEATRE_H

#include "client.h"

#define MAX_ESP 10
#define MAX_CLI 50

typedef struct
{
    int nesp;                           /* Número d'espectacles */
    int ncli;                           /* Número de clients    */
    t_espectacle espectacles[MAX_ESP];  /* Array d'espectacles  */
    t_client clients[MAX_CLI];          /* Array de clients     */
}t_teatre;

t_client * buscar_client(t_teatre *t, t_nif nif);
t_espectacle * buscar_espectacle (t_teatre *t, char titol[MAX_C]);
void registrar_nou_client(t_teatre *t);
void introduir_nou_espectacle(t_teatre *t);
void mostrar_espectacles(t_teatre *t);
void veure_estat_butaques(t_teatre *t);
void comprar_entrada_sessio(t_teatre *t);
void mostrar_dades_client(t_teatre *t);

#endif /* TEATRE_H */

