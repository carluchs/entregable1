/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#ifndef ESPECTACLE_H
#define ESPECTACLE_H

#define LLIURE  0
#define OCUPADA 1
#define NUM_F   8
#define NUM_B   12
#define MAX_C   20
#define MAX_S   4

typedef struct
{
    int fila;       /* Número de fila on és la butaca   */
    int numero;     /* Número de butaca a la seva fila  */
    int estat;      /* Camp amb valor LLIURE o OCUPADA  */                  
}t_butaca;

typedef struct
{
    int data;                         /* Data (format: aaaammdd)       */
    int hora_ini;                     /* Hora d'inici (format: hhmm)   */
    t_butaca butaques[NUM_F][NUM_B];  /* Matriu de butaques del teatre */
    float preu;                       /* Preu de l'entrada (euros)     */
}t_sessio;

typedef struct
{
    char titol[MAX_C];          /* Títol de l'espectacle */
    int durada;                 /* Durada en minuts      */
    int nsessions;              /* Número de sessions    */
    t_sessio sessions[MAX_S];   /* Array de sessions     */
}t_espectacle;

int llegir_data();
int llegir_hora();
void mostrar_data(int data);
void mostrar_hora(int hora);
t_sessio llegir_nova_sessio();
t_espectacle llegir_nou_espectacle();
void preparar_butaques(t_sessio *s);
void mostrar_espectacle(t_espectacle *e);
void mostrar_estat_butaques(t_sessio *s);
t_sessio * buscar_sessio(t_espectacle *e, int data, int hora);
t_butaca * buscar_butaca(t_sessio *s, int fila, int num);

#endif /* ESPECTACLE_H */

