/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#ifndef CLIENT_H
#define CLIENT_H

#include "espectacle.h"

#define MAX_E   10

typedef struct
{
    int numero;     /* Número del NIF */
    char lletra;    /* Lletra del NIF */
}t_nif;

typedef struct
{
    t_espectacle *espectacle;  /* Espectacle del teatre      */
    t_sessio *sessio;          /* Sessió de l'espectacle     */
    t_butaca *butaca;          /* Butaca reservada           */
}t_entrada;

typedef struct
{
    t_nif nif;                  /* NIF del client              */       
    char nom[MAX_C];            /* Nom i cognoms del client    */
    float moneder;              /* Moneder virtual (euros)     */
    int nentrades;              /* Número d'entrades comprades */
    t_entrada entrades[MAX_E];  /* Array d'entrades comprades  */
}t_client;

t_nif llegir_nif();
t_client llegir_client();
void mostrar_client(t_client c);
int comprar_entrada(t_client *c, t_espectacle *e, t_sessio *s, t_butaca *b);

#endif /* CLIENT_H */
